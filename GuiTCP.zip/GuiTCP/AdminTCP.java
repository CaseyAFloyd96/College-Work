
package GuiTCP;
import static com.sun.xml.internal.fastinfoset.alphabet.BuiltInRestrictedAlphabets.table;
import java.awt.Component;
import java.io.*;
import java.net.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import java.lang.StringBuilder;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JTable;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumnModel;

public class AdminTCP extends javax.swing.JFrame {
    
    public String port;
    public int prt;
    public String ipAdd;
    public Socket clientSocket;
    public DefaultTableModel myClasses;

    public AdminTCP() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        Socket = new javax.swing.JPanel();
        submit = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jTextArea3 = new javax.swing.JTextArea();
        jTextArea6 = new javax.swing.JTextArea();
        Login = new javax.swing.JPanel();
        login = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jTextArea5 = new javax.swing.JTextArea();
        jLabel9 = new javax.swing.JLabel();
        jTextArea4 = new javax.swing.JPasswordField();
        Register = new javax.swing.JPanel();
        jTextArea8 = new javax.swing.JTextArea();
        jTextArea9 = new javax.swing.JTextArea();
        jTextArea10 = new javax.swing.JTextArea();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        register = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        jTextArea7 = new javax.swing.JPasswordField();
        Home = new javax.swing.JPanel();
        jTabbedPane2 = new javax.swing.JTabbedPane();
        MyClasses = new javax.swing.JPanel();
        jScrollPane6 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        logout = new javax.swing.JButton();
        jLabel39 = new javax.swing.JLabel();
        Search = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jLabel27 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea2 = new javax.swing.JTextArea();
        ClassSearch = new javax.swing.JButton();
        jLabel37 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel40 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        CreateAClass = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jCheckBox2 = new javax.swing.JCheckBox();
        jCheckBox3 = new javax.swing.JCheckBox();
        jCheckBox4 = new javax.swing.JCheckBox();
        jCheckBox5 = new javax.swing.JCheckBox();
        jCheckBox6 = new javax.swing.JCheckBox();
        jCheckBox7 = new javax.swing.JCheckBox();
        jCheckBox8 = new javax.swing.JCheckBox();
        jTextArea11 = new javax.swing.JTextArea();
        jTextArea12 = new javax.swing.JTextArea();
        jTextArea13 = new javax.swing.JTextArea();
        jTextArea14 = new javax.swing.JTextArea();
        jTextArea15 = new javax.swing.JTextArea();
        jTextArea16 = new javax.swing.JTextArea();
        jTextArea17 = new javax.swing.JTextArea();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jTextArea18 = new javax.swing.JTextArea();
        jTextArea27 = new javax.swing.JTextArea();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jTextArea28 = new javax.swing.JTextArea();
        jTextArea29 = new javax.swing.JTextArea();
        jLabel24 = new javax.swing.JLabel();
        jTextArea30 = new javax.swing.JTextArea();
        jCheckBox1 = new javax.swing.JCheckBox();
        jCheckBox10 = new javax.swing.JCheckBox();
        CreateClass = new javax.swing.JButton();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        TrackAttendance = new javax.swing.JPanel();
        jTextArea19 = new javax.swing.JTextArea();
        jTextArea20 = new javax.swing.JTextArea();
        jTextArea21 = new javax.swing.JTextArea();
        jTextArea22 = new javax.swing.JTextArea();
        jLabel41 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        track = new javax.swing.JButton();
        jLabel45 = new javax.swing.JLabel();
        AttendanceReports = new javax.swing.JPanel();
        jTextArea23 = new javax.swing.JTextArea();
        GenerateReport = new javax.swing.JButton();
        jLabel46 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        jLabel47 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTabbedPane1.setBackground(new java.awt.Color(255, 255, 204));
        jTabbedPane1.setToolTipText("");
        jTabbedPane1.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 13)); // NOI18N

        submit.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 13)); // NOI18N
        submit.setText("Submit");
        submit.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        submit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 13)); // NOI18N
        jLabel1.setText("IP Address:");

        jLabel2.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 13)); // NOI18N
        jLabel2.setText("Port:");

        jTextArea3.setColumns(20);
        jTextArea3.setRows(5);
        jTextArea3.setFocusCycleRoot(true);
        jTextArea3.setNextFocusableComponent(submit);

        jTextArea6.setColumns(20);
        jTextArea6.setRows(5);
        jTextArea6.setFocusCycleRoot(true);
        jTextArea6.setNextFocusableComponent(jTextArea3);

        javax.swing.GroupLayout SocketLayout = new javax.swing.GroupLayout(Socket);
        Socket.setLayout(SocketLayout);
        SocketLayout.setHorizontalGroup(
            SocketLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SocketLayout.createSequentialGroup()
                .addGroup(SocketLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(SocketLayout.createSequentialGroup()
                        .addGroup(SocketLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(SocketLayout.createSequentialGroup()
                                .addGap(90, 90, 90)
                                .addComponent(jLabel1)
                                .addGap(18, 18, 18))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SocketLayout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel2)
                                .addGap(36, 36, 36)))
                        .addGroup(SocketLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextArea6, javax.swing.GroupLayout.PREFERRED_SIZE, 288, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextArea3, javax.swing.GroupLayout.PREFERRED_SIZE, 288, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(SocketLayout.createSequentialGroup()
                        .addGap(271, 271, 271)
                        .addComponent(submit, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(605, Short.MAX_VALUE))
        );
        SocketLayout.setVerticalGroup(
            SocketLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(SocketLayout.createSequentialGroup()
                .addGroup(SocketLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(SocketLayout.createSequentialGroup()
                        .addGap(72, 72, 72)
                        .addComponent(jTextArea6, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(SocketLayout.createSequentialGroup()
                        .addGap(84, 84, 84)
                        .addComponent(jLabel1)))
                .addGap(60, 60, 60)
                .addGroup(SocketLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTextArea3, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(SocketLayout.createSequentialGroup()
                        .addGap(13, 13, 13)
                        .addComponent(jLabel2)))
                .addGap(71, 71, 71)
                .addComponent(submit, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(270, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Socket", Socket);

        login.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 13)); // NOI18N
        login.setText("Login");
        login.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        login.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 16)); // NOI18N
        jLabel3.setText("Username:");

        jLabel4.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 16)); // NOI18N
        jLabel4.setText("Password:");

        jTextArea5.setColumns(20);
        jTextArea5.setRows(5);
        jTextArea5.setFocusCycleRoot(true);
        jTextArea5.setNextFocusableComponent(jTextArea4);

        jLabel9.setForeground(new java.awt.Color(200, 0, 0));

        jTextArea4.setFocusCycleRoot(true);
        jTextArea4.setNextFocusableComponent(Login);

        javax.swing.GroupLayout LoginLayout = new javax.swing.GroupLayout(Login);
        Login.setLayout(LoginLayout);
        LoginLayout.setHorizontalGroup(
            LoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(LoginLayout.createSequentialGroup()
                .addGroup(LoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(LoginLayout.createSequentialGroup()
                        .addGap(132, 132, 132)
                        .addGroup(LoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(LoginLayout.createSequentialGroup()
                                .addGroup(LoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel3))
                                .addGap(39, 39, 39)
                                .addGroup(LoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jTextArea5, javax.swing.GroupLayout.DEFAULT_SIZE, 207, Short.MAX_VALUE)
                                    .addComponent(jTextArea4)))
                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 343, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(LoginLayout.createSequentialGroup()
                        .addGap(263, 263, 263)
                        .addComponent(login, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(599, Short.MAX_VALUE))
        );
        LoginLayout.setVerticalGroup(
            LoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(LoginLayout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(LoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel3)
                    .addComponent(jTextArea5, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(55, 55, 55)
                .addGroup(LoginLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel4)
                    .addComponent(jTextArea4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(65, 65, 65)
                .addComponent(login, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(308, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Login", Login);

        jTextArea8.setColumns(20);
        jTextArea8.setRows(5);
        jTextArea8.setFocusCycleRoot(true);
        jTextArea8.setName(""); // NOI18N
        jTextArea8.setNextFocusableComponent(jTextArea9);

        jTextArea9.setColumns(20);
        jTextArea9.setRows(5);
        jTextArea9.setFocusCycleRoot(true);
        jTextArea9.setNextFocusableComponent(Register);

        jTextArea10.setColumns(20);
        jTextArea10.setRows(5);
        jTextArea10.setFocusCycleRoot(true);
        jTextArea10.setNextFocusableComponent(jTextArea7);

        jLabel5.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 16)); // NOI18N
        jLabel5.setText("Username:");

        jLabel6.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 16)); // NOI18N
        jLabel6.setText("Password:");

        jLabel7.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 16)); // NOI18N
        jLabel7.setText("First Name:");

        jLabel8.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 16)); // NOI18N
        jLabel8.setText("Last Name:");

        register.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 13)); // NOI18N
        register.setText("Register");
        register.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        register.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registerActionPerformed(evt);
            }
        });

        jLabel10.setForeground(new java.awt.Color(200, 0, 0));

        jTextArea7.setFocusCycleRoot(true);
        jTextArea7.setNextFocusableComponent(jTextArea8);

        javax.swing.GroupLayout RegisterLayout = new javax.swing.GroupLayout(Register);
        Register.setLayout(RegisterLayout);
        RegisterLayout.setHorizontalGroup(
            RegisterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(RegisterLayout.createSequentialGroup()
                .addGroup(RegisterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(RegisterLayout.createSequentialGroup()
                        .addGap(207, 207, 207)
                        .addGroup(RegisterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel6)
                            .addComponent(jLabel5)
                            .addComponent(jLabel7)
                            .addComponent(jLabel8))
                        .addGap(120, 120, 120)
                        .addGroup(RegisterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextArea10, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextArea7, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextArea8, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextArea9, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(RegisterLayout.createSequentialGroup()
                        .addGap(261, 261, 261)
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 295, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(RegisterLayout.createSequentialGroup()
                        .addGap(345, 345, 345)
                        .addComponent(register, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(449, Short.MAX_VALUE))
        );
        RegisterLayout.setVerticalGroup(
            RegisterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(RegisterLayout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(RegisterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jTextArea10, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addGap(55, 55, 55)
                .addGroup(RegisterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jTextArea7, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addGap(55, 55, 55)
                .addGroup(RegisterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jTextArea8, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addGap(54, 54, 54)
                .addGroup(RegisterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jTextArea9, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addGap(71, 71, 71)
                .addComponent(register, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(143, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Register", Register);

        Home.setEnabled(false);
        Home.addHierarchyListener(new java.awt.event.HierarchyListener() {
            public void hierarchyChanged(java.awt.event.HierarchyEvent evt) {
                HomeHierarchyChanged(evt);
            }
        });

        jTabbedPane2.setBackground(new java.awt.Color(255, 255, 204));
        jTabbedPane2.setEnabled(false);
        jTabbedPane2.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 13)); // NOI18N

        jScrollPane6.setBorder(null);

        jTable2.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Class ID", "Class Name", "Institution", "Admin", "Start Date", "End Date", "Days/Times"
            }
        ));
        jScrollPane6.setViewportView(jTable2);

        logout.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 13)); // NOI18N
        logout.setText("Logout");
        logout.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        logout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logoutActionPerformed(evt);
            }
        });

        jLabel39.setFont(new java.awt.Font("Arial Black", 0, 18)); // NOI18N
        jLabel39.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel39.setText("My Classes");

        javax.swing.GroupLayout MyClassesLayout = new javax.swing.GroupLayout(MyClasses);
        MyClasses.setLayout(MyClassesLayout);
        MyClassesLayout.setHorizontalGroup(
            MyClassesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MyClassesLayout.createSequentialGroup()
                .addGroup(MyClassesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(MyClassesLayout.createSequentialGroup()
                        .addGap(317, 317, 317)
                        .addComponent(jLabel39, javax.swing.GroupLayout.PREFERRED_SIZE, 409, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(MyClassesLayout.createSequentialGroup()
                        .addGap(488, 488, 488)
                        .addComponent(logout, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(MyClassesLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 958, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(99, Short.MAX_VALUE))
        );
        MyClassesLayout.setVerticalGroup(
            MyClassesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(MyClassesLayout.createSequentialGroup()
                .addGap(93, 93, 93)
                .addComponent(jLabel39, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(71, 71, 71)
                .addComponent(logout, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(175, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("My Classes", MyClasses);

        jScrollPane1.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane1.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        jLabel27.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 13)); // NOI18N
        jLabel27.setText("Class Name:");
        jLabel27.setToolTipText("");

        jLabel36.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 13)); // NOI18N
        jLabel36.setText("Institution:");

        jScrollPane2.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane2.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        jTextArea2.setColumns(20);
        jTextArea2.setRows(5);
        jScrollPane2.setViewportView(jTextArea2);

        ClassSearch.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 13)); // NOI18N
        ClassSearch.setText("Search");
        ClassSearch.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        ClassSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ClassSearchActionPerformed(evt);
            }
        });

        jLabel37.setForeground(new java.awt.Color(200, 0, 0));
        jLabel37.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        jScrollPane3.setBorder(null);

        jTable1.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Class ID", "Class Name", "Institution", "Admin", "Start Date", "End Date", "Days/Times"
            }
        ));
        jTable1.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_LAST_COLUMN);
        jScrollPane3.setViewportView(jTable1);

        jLabel38.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel38.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout SearchLayout = new javax.swing.GroupLayout(Search);
        Search.setLayout(SearchLayout);
        SearchLayout.setHorizontalGroup(
            SearchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SearchLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(SearchLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 1022, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel40)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(SearchLayout.createSequentialGroup()
                .addGap(71, 71, 71)
                .addComponent(jLabel27)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(92, 92, 92)
                .addComponent(jLabel36)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(52, 52, 52)
                .addComponent(ClassSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(SearchLayout.createSequentialGroup()
                .addGap(304, 304, 304)
                .addComponent(jLabel38, javax.swing.GroupLayout.PREFERRED_SIZE, 436, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(SearchLayout.createSequentialGroup()
                .addGap(350, 350, 350)
                .addComponent(jLabel37, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        SearchLayout.setVerticalGroup(
            SearchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SearchLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel37, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(SearchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(ClassSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(SearchLayout.createSequentialGroup()
                        .addGroup(SearchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel27)
                            .addComponent(jLabel36))
                        .addGap(8, 8, 8)))
                .addGap(49, 49, 49)
                .addComponent(jLabel38, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(SearchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(SearchLayout.createSequentialGroup()
                        .addGap(212, 212, 212)
                        .addComponent(jLabel40))
                    .addGroup(SearchLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 126, Short.MAX_VALUE)
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31))
        );

        jTabbedPane2.addTab("Class Search", Search);

        jLabel12.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 12)); // NOI18N
        jLabel12.setText("Class Name: ");

        jLabel13.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 12)); // NOI18N
        jLabel13.setText("Institution Name: ");

        jLabel14.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 12)); // NOI18N
        jLabel14.setText("Days of the Week:");

        jCheckBox2.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 13)); // NOI18N
        jCheckBox2.setText("M");
        jCheckBox2.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jCheckBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox2ActionPerformed(evt);
            }
        });

        jCheckBox3.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 13)); // NOI18N
        jCheckBox3.setText("T");
        jCheckBox3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox3ActionPerformed(evt);
            }
        });

        jCheckBox4.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 13)); // NOI18N
        jCheckBox4.setText("W");
        jCheckBox4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox4ActionPerformed(evt);
            }
        });

        jCheckBox5.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 13)); // NOI18N
        jCheckBox5.setText("R");
        jCheckBox5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox5ActionPerformed(evt);
            }
        });

        jCheckBox6.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 13)); // NOI18N
        jCheckBox6.setText("F");
        jCheckBox6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox6ActionPerformed(evt);
            }
        });

        jCheckBox7.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 13)); // NOI18N
        jCheckBox7.setText("S");
        jCheckBox7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox7ActionPerformed(evt);
            }
        });

        jCheckBox8.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 13)); // NOI18N
        jCheckBox8.setText("U");
        jCheckBox8.setToolTipText("");
        jCheckBox8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox8ActionPerformed(evt);
            }
        });

        jTextArea11.setColumns(20);
        jTextArea11.setRows(5);
        jTextArea11.setToolTipText("HHMM-HHMM");
        jTextArea11.setEnabled(false);

        jTextArea12.setColumns(20);
        jTextArea12.setRows(5);
        jTextArea12.setToolTipText("HHMM-HHMM");
        jTextArea12.setEnabled(false);

        jTextArea13.setColumns(20);
        jTextArea13.setRows(5);
        jTextArea13.setToolTipText("HHMM-HHMM");
        jTextArea13.setEnabled(false);

        jTextArea14.setColumns(20);
        jTextArea14.setRows(5);
        jTextArea14.setToolTipText("HHMM-HHMM");
        jTextArea14.setEnabled(false);

        jTextArea15.setColumns(20);
        jTextArea15.setRows(5);
        jTextArea15.setToolTipText("HHMM-HHMM");
        jTextArea15.setEnabled(false);

        jTextArea16.setColumns(20);
        jTextArea16.setRows(5);
        jTextArea16.setToolTipText("HHMM-HHMM");
        jTextArea16.setEnabled(false);

        jTextArea17.setColumns(20);
        jTextArea17.setRows(5);
        jTextArea17.setToolTipText("HHMM-HHMM");
        jTextArea17.setEnabled(false);

        jLabel15.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 12)); // NOI18N
        jLabel15.setText("Time:");

        jLabel16.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 12)); // NOI18N
        jLabel16.setText("Time:");

        jLabel17.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 12)); // NOI18N
        jLabel17.setText("Time:");

        jLabel18.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 12)); // NOI18N
        jLabel18.setText("Time:");

        jLabel19.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 12)); // NOI18N
        jLabel19.setText("Time:");

        jLabel20.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 12)); // NOI18N
        jLabel20.setText("Time:");

        jLabel21.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 12)); // NOI18N
        jLabel21.setText("Time:");

        jTextArea18.setColumns(20);
        jTextArea18.setRows(5);
        jTextArea18.setToolTipText("");

        jTextArea27.setColumns(20);
        jTextArea27.setRows(5);
        jTextArea27.setToolTipText("");

        jLabel22.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 12)); // NOI18N
        jLabel22.setText("Start Date:");

        jLabel23.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 12)); // NOI18N
        jLabel23.setText("End Date:");

        jTextArea28.setColumns(20);
        jTextArea28.setRows(5);
        jTextArea28.setToolTipText("MM-DD-YYYY");

        jTextArea29.setColumns(20);
        jTextArea29.setRows(5);
        jTextArea29.setToolTipText("MM-DD-YYYY");

        jLabel24.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 12)); // NOI18N
        jLabel24.setText("Do you know the IP Address of the STAC Network or are you on the STAC Network?");

        jTextArea30.setColumns(20);
        jTextArea30.setRows(5);
        jTextArea30.setToolTipText("");

        jCheckBox1.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 13)); // NOI18N
        jCheckBox1.setText("I Know It: ");
        jCheckBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox1ActionPerformed(evt);
            }
        });

        jCheckBox10.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 13)); // NOI18N
        jCheckBox10.setText("I'm Connected To It");

        CreateClass.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 13)); // NOI18N
        CreateClass.setText("Create");
        CreateClass.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        CreateClass.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CreateClassActionPerformed(evt);
            }
        });

        jLabel25.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 10)); // NOI18N
        jLabel25.setText("(MM-DD-YYYY)");

        jLabel26.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 10)); // NOI18N
        jLabel26.setText("(MM-DD-YYYY)");

        jLabel28.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 10)); // NOI18N
        jLabel28.setText("(HHMM-HHMM)");

        jLabel29.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 10)); // NOI18N
        jLabel29.setText("(HHMM-HHMM)");

        jLabel30.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 10)); // NOI18N
        jLabel30.setText("(HHMM-HHMM)");

        jLabel31.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 10)); // NOI18N
        jLabel31.setText("(HHMM-HHMM)");

        jLabel32.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 10)); // NOI18N
        jLabel32.setText("(HHMM-HHMM)");

        jLabel33.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 10)); // NOI18N
        jLabel33.setText("(HHMM-HHMM)");

        jLabel34.setForeground(new java.awt.Color(200, 0, 0));
        jLabel34.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel34.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        jLabel35.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 10)); // NOI18N
        jLabel35.setText("(HHMM-HHMM)");

        javax.swing.GroupLayout CreateAClassLayout = new javax.swing.GroupLayout(CreateAClass);
        CreateAClass.setLayout(CreateAClassLayout);
        CreateAClassLayout.setHorizontalGroup(
            CreateAClassLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CreateAClassLayout.createSequentialGroup()
                .addGroup(CreateAClassLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel34, javax.swing.GroupLayout.PREFERRED_SIZE, 595, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(CreateAClassLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(CreateAClassLayout.createSequentialGroup()
                            .addGap(50, 50, 50)
                            .addComponent(jLabel14)
                            .addGap(18, 18, 18)
                            .addGroup(CreateAClassLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(CreateAClassLayout.createSequentialGroup()
                                    .addComponent(jCheckBox8)
                                    .addGap(38, 38, 38)
                                    .addComponent(jLabel20)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(jLabel32))
                                .addGroup(CreateAClassLayout.createSequentialGroup()
                                    .addComponent(jCheckBox7)
                                    .addGap(41, 41, 41)
                                    .addComponent(jLabel19)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(jLabel31))
                                .addGroup(CreateAClassLayout.createSequentialGroup()
                                    .addComponent(jCheckBox5)
                                    .addGap(43, 43, 43)
                                    .addComponent(jLabel17)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(jLabel29))
                                .addGroup(CreateAClassLayout.createSequentialGroup()
                                    .addComponent(jCheckBox4)
                                    .addGap(39, 39, 39)
                                    .addComponent(jLabel15)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(jLabel28))
                                .addGroup(CreateAClassLayout.createSequentialGroup()
                                    .addGroup(CreateAClassLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jCheckBox2)
                                        .addComponent(jCheckBox3))
                                    .addGap(41, 41, 41)
                                    .addGroup(CreateAClassLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(CreateAClassLayout.createSequentialGroup()
                                            .addComponent(jLabel16)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                            .addComponent(jLabel35)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addGroup(CreateAClassLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addGroup(CreateAClassLayout.createSequentialGroup()
                                                    .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                    .addComponent(jLabel25))
                                                .addGroup(CreateAClassLayout.createSequentialGroup()
                                                    .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                    .addComponent(jLabel26)))
                                            .addGap(40, 40, 40)
                                            .addGroup(CreateAClassLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(jTextArea29, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(jTextArea28, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGroup(CreateAClassLayout.createSequentialGroup()
                                            .addComponent(jLabel21)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                            .addComponent(jLabel33))))
                                .addGroup(CreateAClassLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addGroup(CreateAClassLayout.createSequentialGroup()
                                        .addGroup(CreateAClassLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(CreateAClassLayout.createSequentialGroup()
                                                .addComponent(jCheckBox1)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jTextArea30, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(CreateClass, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jCheckBox10))
                                    .addComponent(jLabel24))
                                .addGroup(CreateAClassLayout.createSequentialGroup()
                                    .addComponent(jCheckBox6)
                                    .addGap(40, 40, 40)
                                    .addComponent(jLabel18)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(jLabel30)
                                    .addGap(41, 41, 41)
                                    .addGroup(CreateAClassLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(jTextArea13, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jTextArea12, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jTextArea14, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jTextArea15, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jTextArea16, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jTextArea17, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jTextArea11, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addGroup(CreateAClassLayout.createSequentialGroup()
                            .addGap(24, 24, 24)
                            .addComponent(jLabel13)
                            .addGap(18, 18, 18)
                            .addComponent(jTextArea18, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(CreateAClassLayout.createSequentialGroup()
                            .addGap(46, 46, 46)
                            .addComponent(jLabel12)
                            .addGap(18, 18, 18)
                            .addComponent(jTextArea27, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        CreateAClassLayout.setVerticalGroup(
            CreateAClassLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CreateAClassLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel34, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(CreateAClassLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextArea27, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextArea28, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel25))
                .addGap(26, 26, 26)
                .addGroup(CreateAClassLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextArea18, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextArea29, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel26))
                .addGap(18, 18, 18)
                .addGroup(CreateAClassLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jCheckBox2)
                    .addComponent(jTextArea11, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel35, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(CreateAClassLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jCheckBox3)
                    .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel33)
                    .addComponent(jTextArea17, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(13, 13, 13)
                .addGroup(CreateAClassLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextArea12, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel28)
                    .addComponent(jCheckBox4))
                .addGap(6, 6, 6)
                .addGroup(CreateAClassLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextArea13, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel29)
                    .addComponent(jCheckBox5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(CreateAClassLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextArea14, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel30)
                    .addComponent(jCheckBox6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(CreateAClassLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextArea15, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel31)
                    .addComponent(jCheckBox7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(CreateAClassLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextArea16, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel32)
                    .addComponent(jCheckBox8))
                .addGap(18, 18, 18)
                .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(19, 19, 19)
                .addGroup(CreateAClassLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jCheckBox1)
                    .addComponent(jTextArea30, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jCheckBox10))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 37, Short.MAX_VALUE)
                .addComponent(CreateClass, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28))
        );

        jTabbedPane2.addTab("Create a Class", CreateAClass);

        jTextArea19.setColumns(20);
        jTextArea19.setRows(5);

        jTextArea20.setColumns(20);
        jTextArea20.setRows(5);

        jTextArea21.setColumns(20);
        jTextArea21.setRows(5);

        jTextArea22.setColumns(20);
        jTextArea22.setRows(5);

        jLabel41.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 13)); // NOI18N
        jLabel41.setText("Class ID:");

        jLabel42.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 13)); // NOI18N
        jLabel42.setText("Username:");

        jLabel43.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 13)); // NOI18N
        jLabel43.setText("Attendance Date:");

        jLabel44.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 13)); // NOI18N
        jLabel44.setText("Attendance Time:");

        track.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 13)); // NOI18N
        track.setText("Track");
        track.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        track.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                trackActionPerformed(evt);
            }
        });

        jLabel45.setForeground(new java.awt.Color(200, 0, 0));
        jLabel45.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout TrackAttendanceLayout = new javax.swing.GroupLayout(TrackAttendance);
        TrackAttendance.setLayout(TrackAttendanceLayout);
        TrackAttendanceLayout.setHorizontalGroup(
            TrackAttendanceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TrackAttendanceLayout.createSequentialGroup()
                .addGap(323, 323, 323)
                .addGroup(TrackAttendanceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel42)
                    .addComponent(jLabel41, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 120, Short.MAX_VALUE)
                .addGroup(TrackAttendanceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jTextArea19, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                    .addComponent(jTextArea20)
                    .addComponent(jTextArea22)
                    .addComponent(jTextArea21))
                .addGap(355, 355, 355))
            .addGroup(TrackAttendanceLayout.createSequentialGroup()
                .addGap(297, 297, 297)
                .addGroup(TrackAttendanceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel44)
                    .addComponent(jLabel43))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(TrackAttendanceLayout.createSequentialGroup()
                .addGroup(TrackAttendanceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(TrackAttendanceLayout.createSequentialGroup()
                        .addGap(433, 433, 433)
                        .addComponent(track, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(TrackAttendanceLayout.createSequentialGroup()
                        .addGap(298, 298, 298)
                        .addComponent(jLabel45, javax.swing.GroupLayout.PREFERRED_SIZE, 415, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        TrackAttendanceLayout.setVerticalGroup(
            TrackAttendanceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TrackAttendanceLayout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addComponent(jLabel45, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(53, 53, 53)
                .addGroup(TrackAttendanceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(TrackAttendanceLayout.createSequentialGroup()
                        .addGroup(TrackAttendanceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jTextArea19, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel41))
                        .addGap(41, 41, 41)
                        .addComponent(jTextArea20, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel42))
                .addGap(42, 42, 42)
                .addGroup(TrackAttendanceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jTextArea22, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel43))
                .addGap(35, 35, 35)
                .addGroup(TrackAttendanceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel44)
                    .addComponent(jTextArea21, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(81, 81, 81)
                .addComponent(track, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(108, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Track Attendance", TrackAttendance);

        jTextArea23.setColumns(20);
        jTextArea23.setRows(5);

        GenerateReport.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 13)); // NOI18N
        GenerateReport.setText("Generate Report");
        GenerateReport.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        GenerateReport.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GenerateReportActionPerformed(evt);
            }
        });

        jLabel46.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 14)); // NOI18N
        jLabel46.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel46.setText("Enter Class ID:");

        jScrollPane4.setBorder(null);

        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Username", "Number of Classes Attended"
            }
        ));
        jScrollPane4.setViewportView(jTable3);

        jLabel47.setForeground(new java.awt.Color(200, 0, 0));
        jLabel47.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout AttendanceReportsLayout = new javax.swing.GroupLayout(AttendanceReports);
        AttendanceReports.setLayout(AttendanceReportsLayout);
        AttendanceReportsLayout.setHorizontalGroup(
            AttendanceReportsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, AttendanceReportsLayout.createSequentialGroup()
                .addContainerGap(232, Short.MAX_VALUE)
                .addGroup(AttendanceReportsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jLabel47, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(AttendanceReportsLayout.createSequentialGroup()
                        .addComponent(jLabel46, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(102, 102, 102)
                        .addComponent(jTextArea23, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(387, 387, 387))
            .addGroup(AttendanceReportsLayout.createSequentialGroup()
                .addGroup(AttendanceReportsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(AttendanceReportsLayout.createSequentialGroup()
                        .addGap(370, 370, 370)
                        .addComponent(GenerateReport, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(AttendanceReportsLayout.createSequentialGroup()
                        .addGap(149, 149, 149)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 645, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        AttendanceReportsLayout.setVerticalGroup(
            AttendanceReportsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(AttendanceReportsLayout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addComponent(jLabel47, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(AttendanceReportsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel46, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
                    .addComponent(jTextArea23, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addGap(46, 46, 46)
                .addComponent(GenerateReport, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 64, Short.MAX_VALUE)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 253, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(55, 55, 55))
        );

        jTabbedPane2.addTab("Attendance Reports", AttendanceReports);

        javax.swing.GroupLayout HomeLayout = new javax.swing.GroupLayout(Home);
        Home.setLayout(HomeLayout);
        HomeLayout.setHorizontalGroup(
            HomeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane2)
        );
        HomeLayout.setVerticalGroup(
            HomeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, HomeLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jTabbedPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 588, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jTabbedPane1.addTab("Home", null, Home, "");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void submitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitActionPerformed
        port = jTextArea3.getText();
        prt = Integer.parseInt(port); 
        ipAdd = jTextArea6.getText();
        jTextArea4.setText("");
        jTextArea5.setText("");
        int n = jTabbedPane1.indexOfTab("Login");
        jTabbedPane1.setSelectedIndex(n);
        int s = jTabbedPane1.indexOfTab("Socket");
        jTabbedPane1.setEnabledAt(s, false);
        int h = jTabbedPane1.indexOfTab("Home");
        jTabbedPane1.setEnabledAt(h, false);
        System.out.println("Connection Established");
        try {
            clientSocket = new Socket(ipAdd, prt);
        } catch (IOException ex) {
            Logger.getLogger(AdminTCP.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_submitActionPerformed

    private void loginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loginActionPerformed
        try {
            String username;
            String password;
            String request = "LOGA";
            String response;
            DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream());
            InputStream is = clientSocket.getInputStream();
            InputStreamReader isr = new InputStreamReader(is);
            BufferedReader inFromServer = new BufferedReader(isr);
            username = jTextArea5.getText();
            
            password = jTextArea4.getText();
            
            Pattern p = Pattern.compile("[^A-Za-z0-9]");
            Matcher m = p.matcher(username);
            Matcher n = p.matcher(password);
            boolean b = m.find();
            boolean c = n.find();
            if (b == true || c == true){
                jLabel9.setText("Invalid Username or Password");
                jTextArea4.setText("");
                jTextArea5.setText("");
            }else if(username.equals("") || password.equals("")){
                jLabel9.setText("Username And/Or Password Cannot Be Blank");
                jTextArea4.setText("");
                jTextArea5.setText("");
            }else{
                String output = (request + " " + '"' + username + '"' + " " + '"' + password + '"' + '\n');

                byte[] input = output.getBytes();
                outToServer.write(input);

                response = inFromServer.readLine();
                if (response.equals("LOGR S") || response.equals("LOGR S ")){

                    Object columnNames[] = {"Class ID", "Class Name", "Institution", "Admin", "Start Date", "End Date", "IP Address", "Days/Times"};
                    myClasses = new DefaultTableModel(columnNames, 0);

                    output = ("CLST"+"\n");
                    byte[] list = output.getBytes();
                    outToServer.write(list);

                    String crns = inFromServer.readLine();
                    if (crns.equals("CLSR F") || crns.equals("CLSR F ")){

                        System.out.println("Login Successful");
                        jLabel11.setText("");

                        int l = jTabbedPane1.indexOfTab("Login");
                        jTabbedPane1.setEnabledAt(l, false);
                        int o = jTabbedPane1.indexOfTab("Register");
                        jTabbedPane1.setEnabledAt(o, false);
                        int i = jTabbedPane1.indexOfTab("Home");
                        jTabbedPane1.setEnabledAt(i, true);
                        jTabbedPane1.setSelectedIndex(i);
                        jTabbedPane2.setEnabled(true);

                        jTextArea5.setText("");
                        jTextArea4.setText("");
                        jLabel9.setText("");

                    }else if (crns.equals("CLSR S ") || crns.equals("CLSR S")){


                        System.out.println("Login Successful");
                        jLabel11.setText("");

                        int l = jTabbedPane1.indexOfTab("Login");
                        jTabbedPane1.setEnabledAt(l, false);
                        int o = jTabbedPane1.indexOfTab("Register");
                        jTabbedPane1.setEnabledAt(o, false);
                        int i = jTabbedPane1.indexOfTab("Home");
                        jTabbedPane1.setEnabledAt(i, true);
                        jTabbedPane1.setSelectedIndex(i);
                        jTabbedPane2.setEnabled(true);

                        jTextArea5.setText("");
                        jTextArea4.setText("");
                        jLabel9.setText("");

                    }else{
                        crns = crns.replace("CLSR S \"","");
                        String[] classes = crns.split("\" \"");

                        int number = classes.length;

                        for (int j = 0; j<number; j++){
                            String temp = classes[j];
                            temp = temp.replace("\" ","");
                            temp = temp.replace("\"","");
                            classes[j] = temp;
                            output = ("CDTL \""+classes[j]+"\""+"\n");
                            byte[] details = output.getBytes();
                            outToServer.write(details);

                            String info = inFromServer.readLine();
                            info = info.replace("CDTR S \"", "");
                            String parts[] = info.split("\" \"");
                            String temp2 = parts[7];
                            temp2 = temp2.replace("\"", "");
                            parts[7] = temp2;
                            myClasses.addRow(parts); 
                        }
                        jTable2.setModel(myClasses);
                        final TableColumnModel columnModel = jTable2.getColumnModel();
                        for (int column = 0; column < jTable2.getColumnCount(); column++) {
                            int width = 15; // Min width
                            for (int row = 0; row < jTable2.getRowCount(); row++) {
                                TableCellRenderer renderer = jTable2.getCellRenderer(row, column);
                                Component comp = jTable2.prepareRenderer(renderer, row, column);
                                width = Math.max(comp.getPreferredSize().width +1 , width);
                            }
                            if(width > 300)
                                width=300;
                            columnModel.getColumn(column).setPreferredWidth(width);
                        }
                        System.out.println("Login Successful");
                        jLabel11.setText("");

                        int l = jTabbedPane1.indexOfTab("Login");
                        jTabbedPane1.setEnabledAt(l, false);
                        int o = jTabbedPane1.indexOfTab("Register");
                        jTabbedPane1.setEnabledAt(o, false);
                        int i = jTabbedPane1.indexOfTab("Home");
                        jTabbedPane1.setEnabledAt(i, true);
                        jTabbedPane1.setSelectedIndex(i);
                        jTabbedPane2.setEnabled(true);

                        jTextArea5.setText("");
                        jTextArea4.setText("");
                        jLabel9.setText("");
                        }

                }else if (response.equals("LOGR F")){
                    System.out.println("Login Failed");
                    jTextArea5.setText("");
                    jTextArea4.setText("");
                    jLabel9.setText("Login Failed. Please Try Again");
                }
            }
        } catch (IOException ex) {
            Logger.getLogger(AdminTCP.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_loginActionPerformed

    private void registerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registerActionPerformed
        try {
            String username;
            String password;
            String FirstName;
            String LastName;
            String request = "REGA";
            String response;
            DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream());
            BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            username = jTextArea10.getText();
            password = jTextArea7.getText();
            FirstName = jTextArea8.getText();
            LastName = jTextArea9.getText();
            
            Pattern p = Pattern.compile("[^A-Za-z0-9]");
            Matcher m = p.matcher(username);
            Matcher n = p.matcher(password);
            Matcher f = p.matcher(FirstName);
            Matcher g = p.matcher(LastName);
            boolean b = m.find();
            boolean c = n.find();
            boolean d = f.find();
            boolean e = g.find();
            
            if(b == true || c == true || d == true || e == true){
                jLabel10.setText("Invalid Input: No Special Characters Allowed");
                jTextArea7.setText("");
                jTextArea8.setText("");
                jTextArea9.setText("");
                jTextArea10.setText("");
            }else if (username.equals("") || password.equals("") || FirstName.equals("") || LastName.equals("")){
                jLabel10.setText("Invalid Input: No Fields Can Be Blank");
            }else{
                String output = (request + " " + '"' + username + '"' + " " + '"' + password + '"' + " " + '"' + FirstName + '"' + " " + '"' + LastName + '"' + '\n');

                byte[] input = output.getBytes();
                outToServer.write(input);

                response = inFromServer.readLine();
                if (response.equals("REGR S") || response.equals("REGR S ")){
                    System.out.println("Registration Successful");
                    jLabel11.setText("");
                    jTextArea7.setText("");
                    jTextArea8.setText("");
                    jTextArea9.setText("");
                    jTextArea10.setText("");

                    Object columnNames[] = {"CLass ID", "Institution", "Class Name", "Admin", "Start Date", "End Date", "IP Address", "Days/Times"};
                    myClasses = new DefaultTableModel(columnNames, 0);
                    jTable2.setModel(myClasses);

                    int l = jTabbedPane1.indexOfTab("Login");
                    jTabbedPane1.setEnabledAt(l, false);
                    int o = jTabbedPane1.indexOfTab("Register");
                    jTabbedPane1.setEnabledAt(o, false);
                    int i = jTabbedPane1.indexOfTab("Home");
                    jTabbedPane1.setEnabledAt(i, true);
                    jTabbedPane1.setSelectedIndex(i);
                    jTabbedPane2.setEnabled(true);

                }else if (response.equals("REGR F") || response.equals("REGR F ")){
                    System.out.println("Regisration Failed");
                    jTextArea7.setText("");
                    jTextArea8.setText("");
                    jTextArea9.setText("");
                    jTextArea10.setText("");
                    jLabel10.setText("Registration Failed. Please Try Again.");
                }
            }
        }
            catch (IOException ex) {
            Logger.getLogger(AdminTCP.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_registerActionPerformed

    private void HomeHierarchyChanged(java.awt.event.HierarchyEvent evt) {//GEN-FIRST:event_HomeHierarchyChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_HomeHierarchyChanged

    private void CreateClassActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CreateClassActionPerformed
        BufferedReader inFromServer = null;
        try {
            String ClassName;
            String Institution;
            String StartDate;
            String EndDate;
            String PublicIPAddress;
            String Monday = "M";
            String Tuesday = "T";
            String Wednesday = "W";
            String Thursday="R";
            String Friday="F";
            String Saturday="S";
            String Sunday="U";
            String Mtime;
            String Ttime;
            String Wtime;
            String Rtime;
            String Ftime;
            String Stime;
            String Utime;
            String output="";

            ClassName = jTextArea27.getText();
            Institution = jTextArea18.getText();
            StartDate = jTextArea28.getText();
            EndDate = jTextArea29.getText();

            if (jCheckBox1.isSelected()){
                PublicIPAddress = jTextArea30.getText();
            }else{
                PublicIPAddress = "";
            }

            StringBuilder out = new StringBuilder();
            out.append("CRCR " + '"' + ClassName + '"' + " " + '"' + Institution
                + '"' + " " + '"' + StartDate + '"' + " " + '"' + EndDate +
                '"' + " " + '"' + PublicIPAddress + '"' + " " + '"');

            if (jCheckBox2.isSelected()){
                Mtime = jTextArea11.getText();
                out.append(Monday+Mtime+";");
            }
            if (jCheckBox3.isSelected()){
                Ttime = jTextArea17.getText();
                out.append(Tuesday+Ttime+";");
            }
            if (jCheckBox4.isSelected()){
                Wtime = jTextArea12.getText();
                out.append(Wednesday+Wtime+";");
            }
            if (jCheckBox5.isSelected()){
                Rtime = jTextArea13.getText();
                out.append(Thursday+Rtime+";");
            }
            if (jCheckBox6.isSelected()){
                Ftime = jTextArea14.getText();
                out.append(Friday+Ftime+";");
            }
            if (jCheckBox7.isSelected()){
                Stime = jTextArea15.getText();
                out.append(Saturday+Stime+";");
            }
            if (jCheckBox8.isSelected()){
                Utime = jTextArea16.getText();
                out.append(Sunday+Utime+";");
            }
            
            out.setLength(out.length()-1);
            out.append("\"" + "\n");
            output = out.toString();
            
            if(ClassName.equals("") || Institution.equals("") || StartDate.equals("") || EndDate.equals("")){
                jLabel34.setText("Cannot have blank fields");
            }else if (!StartDate.matches("\\d{2}-\\d{2}-\\d{4}") || !EndDate.matches("\\d{2}-\\d{2}-\\d{4}")) {
                jLabel34.setText("Invalid Input: Date Format is incorrect");
                jTextArea28.setText("");
                jTextArea29.setText("");
            }else if(!jCheckBox1.isSelected() && !jCheckBox10.isSelected()){
                jLabel34.setText("Must select one of the STAC IP Address options.");
            }else if(!jCheckBox2.isSelected() && !jCheckBox3.isSelected() && !jCheckBox4.isSelected() && !jCheckBox5.isSelected() && 
                    !jCheckBox6.isSelected() && !jCheckBox7.isSelected() && !jCheckBox8.isSelected()){
                jLabel34.setText("Must select at least one day of the week");
            }else{
                DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream());
                inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

                byte[] input = output.getBytes();
                outToServer.write(input);

                String response = inFromServer.readLine();
                
                if (response.equals("CRER F") || response.equals("CRER F ")){
                    jLabel34.setText("Class Creation Failed. Please Try Again");
                    jTextArea11.setText("");
                    jTextArea12.setText("");
                    jTextArea13.setText("");
                    jTextArea14.setText("");
                    jTextArea15.setText("");
                    jTextArea16.setText("");
                    jTextArea17.setText("");
                    jTextArea18.setText("");
                    jTextArea27.setText("");
                    jTextArea28.setText("");
                    jTextArea29.setText("");
                    jTextArea30.setText("");
                    
                    jTextArea11.setEnabled(false);
                    jTextArea12.setEnabled(false);
                    jTextArea13.setEnabled(false);
                    jTextArea14.setEnabled(false);
                    jTextArea15.setEnabled(false);
                    jTextArea16.setEnabled(false);
                    jTextArea17.setEnabled(false);
                    jTextArea30.setEnabled(false);
                    
                    jCheckBox2.setSelected(false);
                    jCheckBox3.setSelected(false);
                    jCheckBox4.setSelected(false);
                    jCheckBox5.setSelected(false);
                    jCheckBox6.setSelected(false);
                    jCheckBox7.setSelected(false);
                    jCheckBox8.setSelected(false);
                    jCheckBox1.setSelected(false);
                    jCheckBox10.setSelected(false);
                }else{
                    String[] parts = response.split(" ");
                    String ID = parts[2];
                    ID = ID.replace("\"","");
                    jLabel34.setText("Class created. The Class ID is "+ID);
                    System.out.println("Class Created");

                    output = ("CDTL \""+ID+'"'+"\n");
                    byte[] details = output.getBytes();
                    outToServer.write(details);

                    String info = inFromServer.readLine();
                    info = info.replace("CDTR S \"", "");
                    String parts2[] = info.split("\" \"");
                    String temp2 = parts2[7];
                    temp2 = temp2.replace("\"", "");
                    parts2[7] = temp2;

                    myClasses.addRow(parts2);
                    jTable2.setModel(myClasses);
                    final TableColumnModel columnModel = jTable2.getColumnModel();
                    for (int column = 0; column < jTable2.getColumnCount(); column++) {
                        int width = 15; // Min width
                        for (int row = 0; row < jTable2.getRowCount(); row++) {
                            TableCellRenderer renderer = jTable2.getCellRenderer(row, column);
                            Component comp = jTable2.prepareRenderer(renderer, row, column);
                            width = Math.max(comp.getPreferredSize().width +1 , width);
                        }
                        if(width > 300)
                            width=300;
                        columnModel.getColumn(column).setPreferredWidth(width);
                    }

                    jTextArea11.setText("");
                    jTextArea12.setText("");
                    jTextArea13.setText("");
                    jTextArea14.setText("");
                    jTextArea15.setText("");
                    jTextArea16.setText("");
                    jTextArea17.setText("");
                    jTextArea18.setText("");
                    jTextArea27.setText("");
                    jTextArea28.setText("");
                    jTextArea29.setText("");
                    jTextArea30.setText("");
                    
                    jTextArea11.setEnabled(false);
                    jTextArea12.setEnabled(false);
                    jTextArea13.setEnabled(false);
                    jTextArea14.setEnabled(false);
                    jTextArea15.setEnabled(false);
                    jTextArea16.setEnabled(false);
                    jTextArea17.setEnabled(false);
                    jTextArea30.setEnabled(false);
                    
                    jCheckBox2.setSelected(false);
                    jCheckBox3.setSelected(false);
                    jCheckBox4.setSelected(false);
                    jCheckBox5.setSelected(false);
                    jCheckBox6.setSelected(false);
                    jCheckBox7.setSelected(false);
                    jCheckBox8.setSelected(false);
                    jCheckBox1.setSelected(false);
                    jCheckBox10.setSelected(false);
                }
            }    
        } catch (IOException ex) {
            Logger.getLogger(AdminTCP.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_CreateClassActionPerformed

    private void ClassSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ClassSearchActionPerformed
        DataOutputStream outToServer = null;
        try {
            outToServer = new DataOutputStream(clientSocket.getOutputStream());
            BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            String ClassName = jTextArea2.getText();
            String Institution = jTextArea1.getText();

            String output = ("CSRC " + '"' + ClassName + '"' + " " + '"' + Institution + '"' +"\n");

            byte[] input = output.getBytes();
            outToServer.write(input);

            String response = inFromServer.readLine();

            Object columnNames[] = {"Class ID", "Class Name", "Institution", "Admin", "Start Date", "End Date", "IP Address", "Days/Times"};
            DefaultTableModel searchModel = new DefaultTableModel(columnNames, 0);

            if (response.equals("CSRR F") || response.equals("CSRR F ")){
                jLabel37.setText("");
                jLabel38.setText("No Results Found");
                jTextArea1.setText("");
                jTextArea2.setText("");
                jTable1.setModel(searchModel);
            }else if(response.equals("CSRR S ") || response.equals("CSRR S")){
                jLabel37.setText("");
                jLabel38.setText("No Results Found");
                jTextArea1.setText("");
                jTextArea2.setText("");
                jTable1.setModel(searchModel);
            }
            else{
                jLabel37.setText("");
                jTextArea1.setText("");
                jTextArea2.setText("");
                jLabel38.setText("Search Results");
                response = response.replace("CSRR S \"","");
                String crns[] = response.split("\" \"");
                int num = crns.length - 1;
                String temp = crns[num];
                temp = temp.replace("\"","");
                crns[num] = temp;

                int number = crns.length;

                for (int j = 0; j<number; j++){

                    String temp3 = crns[j];
                    temp3.trim();
                    crns[j] = temp3;

                    String temp4 = crns[j];
                    temp4 = temp4.replace(" ","");
                    crns[j] = temp4;

                    output = ("CDTL \""+crns[j]+"\""+"\n");
                    byte[] details = output.getBytes();
                    outToServer.write(details);

                    String info = inFromServer.readLine();
                    info = info.replace("CDTR S \"", "");
                    String parts[] = info.split("\" \"");
                    String temp2 = parts[7];
                    temp2 = temp2.replace("\"","");
                    parts[7] = temp2;

                    searchModel.addRow(parts);
                }
                System.out.println("Class Search Successful");
                jTable1.setModel(searchModel);
                final TableColumnModel columnModel = jTable1.getColumnModel();
                for (int column = 0; column < jTable1.getColumnCount(); column++) {
                    int width = 15; // Min width
                    for (int row = 0; row < jTable1.getRowCount(); row++) {
                        TableCellRenderer renderer = jTable1.getCellRenderer(row, column);
                        Component comp = jTable1.prepareRenderer(renderer, row, column);
                        width = Math.max(comp.getPreferredSize().width +1 , width);
                    }
                    if(width > 300)
                        width=300;
                    columnModel.getColumn(column).setPreferredWidth(width);
                }
            }
        } catch (IOException ex) {
            Logger.getLogger(AdminTCP.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_ClassSearchActionPerformed

    private void logoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logoutActionPerformed
        try {
            DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream());
            BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

            String output = ("LOGO"+"\n");

            byte[] input = output.getBytes();
            outToServer.write(input);

            String response = inFromServer.readLine();
            if (response.equals("LOGO S")){

                Object columnNames[] = {"Class ID", "Class Name", "Institution", "Admin", "Start Date", "End Date", "IP Address", "Days/Times"};
                DefaultTableModel logout = new DefaultTableModel(columnNames, 0);
                jTable1.setModel(logout);
                jTable2.setModel(logout);
                
                Object clmNms[] = {"Username", "Number of Classes Attended"};
                DefaultTableModel reset = new DefaultTableModel(clmNms, 0);
                jTable3.setModel(reset);
                
                jLabel47.setText("");
                jLabel45.setText("");
                jLabel34.setText("");
                
                jTextArea11.setText("");
                jTextArea12.setText("");
                jTextArea13.setText("");
                jTextArea14.setText("");
                jTextArea15.setText("");
                jTextArea16.setText("");
                jTextArea17.setText("");
                jTextArea18.setText("");
                jTextArea27.setText("");
                jTextArea28.setText("");
                jTextArea29.setText("");
                jTextArea30.setText("");

                jTextArea11.setEnabled(false);
                jTextArea12.setEnabled(false);
                jTextArea13.setEnabled(false);
                jTextArea14.setEnabled(false);
                jTextArea15.setEnabled(false);
                jTextArea16.setEnabled(false);
                jTextArea17.setEnabled(false);
                jTextArea30.setEnabled(false);

                jCheckBox2.setSelected(false);
                jCheckBox3.setSelected(false);
                jCheckBox4.setSelected(false);
                jCheckBox5.setSelected(false);
                jCheckBox6.setSelected(false);
                jCheckBox7.setSelected(false);
                jCheckBox8.setSelected(false);
                jCheckBox1.setSelected(false);
                jCheckBox10.setSelected(false);
                        
                jLabel37.setText("");
                jLabel38.setText("");
                
                jTextArea19.setText("");
                jTextArea20.setText("");
                jTextArea21.setText("");
                jTextArea22.setText("");
                jTextArea23.setText("");
                
                jTextArea1.setText("");
                jTextArea2.setText("");
                
                jLabel45.setText("");
                jTextArea19.setText("");
                jTextArea20.setText("");
                jTextArea21.setText("");
                jTextArea22.setText("");
                
                jLabel47.setText("");
                jTextArea23.setText("");
                Object columnNames2[] = {"Username", "Number of Classes Attended"};
                DefaultTableModel logout2 = new DefaultTableModel(columnNames2, 0);
                jTable3.setModel(logout2);

                int s = jTabbedPane1.indexOfTab("Socket");
                jTabbedPane1.setEnabledAt(s, true);
                jTabbedPane1.setSelectedIndex(s);
                int n = jTabbedPane1.indexOfTab("Login");
                jTabbedPane1.setEnabledAt(n, true);
                int o = jTabbedPane1.indexOfTab("Register");
                jTabbedPane1.setEnabledAt(o, true);
                int p = jTabbedPane1.indexOfTab("Home");
                jTabbedPane1.setEnabledAt(p, false);
                jLabel9.setText("");
                jLabel10.setText("");
                clientSocket.close();
            }else if(response.equals("LOGO F")){
                jLabel11.setText("Logout Failed. Please Try Again");
            }
        } catch (IOException ex) {
            Logger.getLogger(AdminTCP.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_logoutActionPerformed

    private void jCheckBox3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox3ActionPerformed
        jTextArea17.setEnabled(true);
    }//GEN-LAST:event_jCheckBox3ActionPerformed

    private void jCheckBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox2ActionPerformed
        jTextArea11.setEnabled(true);
    }//GEN-LAST:event_jCheckBox2ActionPerformed

    private void jCheckBox4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox4ActionPerformed
        jTextArea12.setEnabled(true);
    }//GEN-LAST:event_jCheckBox4ActionPerformed

    private void jCheckBox5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox5ActionPerformed
        jTextArea13.setEnabled(true);
    }//GEN-LAST:event_jCheckBox5ActionPerformed

    private void jCheckBox6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox6ActionPerformed
        jTextArea14.setEnabled(true);
    }//GEN-LAST:event_jCheckBox6ActionPerformed

    private void jCheckBox7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox7ActionPerformed
        jTextArea15.setEnabled(true);
    }//GEN-LAST:event_jCheckBox7ActionPerformed

    private void jCheckBox8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox8ActionPerformed
        jTextArea16.setEnabled(true);
    }//GEN-LAST:event_jCheckBox8ActionPerformed

    private void jCheckBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox1ActionPerformed
        jTextArea30.setEnabled(true);
    }//GEN-LAST:event_jCheckBox1ActionPerformed

    private void trackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_trackActionPerformed
        DataOutputStream outToServer = null;
        try {
            outToServer = new DataOutputStream(clientSocket.getOutputStream());
            BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            String ClassID = jTextArea19.getText();
            String UserID = jTextArea20.getText();
            String AttnDate = jTextArea22.getText();
            String AttnTime = jTextArea21.getText();
            
            String request = "MTTN";
            
            Pattern p = Pattern.compile("[^A-Za-z0-9]");
            Matcher m = p.matcher(UserID);
            boolean b = m.find();
            
            if(ClassID.equals("") || UserID.equals("") || AttnDate.equals("") || AttnTime.equals("")){
                jLabel45.setText("No Fields Can Be Blank");
                jTextArea19.setText("");
                jTextArea20.setText("");
                jTextArea21.setText("");
                jTextArea22.setText("");
            }else if(!AttnDate.matches("\\d{2}-\\d{2}-\\d{4}")){
                jLabel45.setText("Date Format is Incorrect (MM-DD-YYYY)");
                jTextArea19.setText("");
                jTextArea20.setText("");
                jTextArea21.setText("");
                jTextArea22.setText("");
            }else if(!AttnTime.matches("\\d{4}")){
                jLabel45.setText("Time Format is Incorrect (HHMM)");
                jTextArea19.setText("");
                jTextArea20.setText("");
                jTextArea21.setText("");
                jTextArea22.setText("");
            }else if(!ClassID.matches("\\d{10}")){
                jLabel45.setText("Class ID can only be a ten digit number");
                jTextArea19.setText("");
                jTextArea20.setText("");
                jTextArea21.setText("");
                jTextArea22.setText("");
            }else if(b == true){
                jLabel45.setText("User ID Can't Contain Special Characters");
                jTextArea19.setText("");
                jTextArea20.setText("");
                jTextArea21.setText("");
                jTextArea22.setText("");
            }else{
                
                String output = (request + " " + '"' + ClassID + '"' + " " + '"' + UserID + '"' + " " + '"' + AttnDate + '"' + " " + '"' + AttnTime + '"' + '\n');

                byte[] input = output.getBytes();
                
                outToServer.write(input);
                
                String response = inFromServer.readLine();
                if (response.equals("MTTR F") || response.equals("MTTR F ")){
                    jLabel45.setText("Could Not Track Attendance. Please Try Again");
                    jTextArea19.setText("");
                    jTextArea20.setText("");
                    jTextArea21.setText("");
                    jTextArea22.setText("");
                }else if (response.equals("MTTR S") || response.equals("MTTR S ")){
                    jLabel45.setText("Attendance Tracked Successfully");
                    System.out.println("Attendance Tracked");
                    jTextArea19.setText("");
                    jTextArea20.setText("");
                    jTextArea21.setText("");
                    jTextArea22.setText("");
                }
                
            }
            
            
        } catch (IOException ex) {
            Logger.getLogger(AdminTCP.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_trackActionPerformed

    private void GenerateReportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GenerateReportActionPerformed
        DataOutputStream outToServer = null;
        try {
            outToServer = new DataOutputStream(clientSocket.getOutputStream());
            BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            String ClassID = jTextArea23.getText();
            
            String request = "ATRP";
            
            if(ClassID.equals("")){
                jLabel47.setText("Class ID Can't Be Blank");
                Object clmNms[] = {"Username", "Number of Classes Attended"};
                DefaultTableModel report = new DefaultTableModel(clmNms, 0);
            }else if(!ClassID.matches("\\d{10}")){
                jLabel47.setText("Class ID can only be a ten digit number");
                Object clmNms[] = {"Username", "Number of Classes Attended"};
                DefaultTableModel report = new DefaultTableModel(clmNms, 0);
            }else{   
                String details = ("CDTL "+ "\""+ClassID+"\""+"\n");
                byte[] rqst = details.getBytes();
                outToServer.write(rqst);
                
                String dtls = inFromServer.readLine();
                dtls = dtls.replace("CDTR S ", "");
                String parts[] = dtls.split("\" \"");
                String temp4 = parts[7];
                temp4 = temp4.replace("\"","");
                
                String daysOfWeek[] = temp4.split(";");
                int days = daysOfWeek.length;
                
                String temp2 = parts[4];
                String temp3 = parts[5];
                String startdates[] = temp2.split("-");
                String enddates[] = temp3.split("-");
                String startYear = startdates[0];
                String startMonth = startdates[1];
                String startDay = startdates[2];
                String endYear = enddates[0];
                String endMonth = enddates[1];
                String endDay = enddates[2];
                
                int sYear = Integer.parseInt(startYear);
                int sMonth = Integer.parseInt(startMonth);
                int sDay = Integer.parseInt(startDay);
                int eYear = Integer.parseInt(endYear);
                int eMonth = Integer.parseInt(endMonth);
                int eDay = Integer.parseInt(endDay);

                Calendar a = new GregorianCalendar(sYear,sMonth,sDay);
                Calendar b = new GregorianCalendar(eYear,eMonth,eDay);
                int startweek = a.get(Calendar.WEEK_OF_YEAR);
                int endweek = b.get(Calendar.WEEK_OF_YEAR);
                
                int weeks = startweek - endweek;
                
                weeks = 52-weeks;
                
                int numClasses = weeks*days;
                
                
                String output = (request + " " + '"' + ClassID + '"' + '\n');

                byte[] input = output.getBytes();
                outToServer.write(input);

                String response = inFromServer.readLine();
                switch (response) {
                    case "ATRR F":
                    case "ATRR F ":
                        {
                            jLabel47.setText("Could Not Generate Report. Please Try Again");
                            Object clmNms[] = {"Username", "Number of Classes Attended"};
                            DefaultTableModel report = new DefaultTableModel(clmNms, 0);
                            jTable3.setModel(report);
                            break;
                        }
                    case "ATRR S":
                    case "ATRR S ":
                    case "ATRR S \"F;0\"":
                        {
                            jLabel47.setText("No Users Enrolled in This Class");
                            Object clmNms[] = {"Username", "Number of Classes Attended"};
                            DefaultTableModel report = new DefaultTableModel(clmNms, 0);
                            jTable3.setModel(report);
                            break;
                        }
                    default:
                        {
                            jLabel47.setText("");
                            Object columnNames[] = {"Username", "Number of Classes Attended out of " + numClasses +" Total"};
                            DefaultTableModel report = new DefaultTableModel(columnNames, 0);
                            response = response.replace("ATRR S \"", "");
                            String seperate[] = response.split("\" \"");
                            int number = seperate.length - 1;
                            String temp = seperate[number];
                            temp = temp.replace("\"","");
                            seperate[number] = temp;
                            for(int i=0;i<=number;i++){
                                String each = seperate[i];
                                String users[] = each.split(";");
                                report.addRow(users);
                            }
                            jTable3.setModel(report);
                            System.out.println("Report Generated");
                            break;
                        }
                }
                
            }
            
            
        } catch (IOException ex) {
            Logger.getLogger(AdminTCP.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_GenerateReportActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AdminTCP.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AdminTCP.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AdminTCP.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AdminTCP.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AdminTCP().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel AttendanceReports;
    private javax.swing.JButton ClassSearch;
    private javax.swing.JPanel CreateAClass;
    private javax.swing.JButton CreateClass;
    private javax.swing.JButton GenerateReport;
    private javax.swing.JPanel Home;
    private javax.swing.JPanel Login;
    private javax.swing.JPanel MyClasses;
    private javax.swing.JPanel Register;
    private javax.swing.JPanel Search;
    private javax.swing.JPanel Socket;
    private javax.swing.JPanel TrackAttendance;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JCheckBox jCheckBox10;
    private javax.swing.JCheckBox jCheckBox2;
    private javax.swing.JCheckBox jCheckBox3;
    private javax.swing.JCheckBox jCheckBox4;
    private javax.swing.JCheckBox jCheckBox5;
    private javax.swing.JCheckBox jCheckBox6;
    private javax.swing.JCheckBox jCheckBox7;
    private javax.swing.JCheckBox jCheckBox8;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextArea jTextArea10;
    private javax.swing.JTextArea jTextArea11;
    private javax.swing.JTextArea jTextArea12;
    private javax.swing.JTextArea jTextArea13;
    private javax.swing.JTextArea jTextArea14;
    private javax.swing.JTextArea jTextArea15;
    private javax.swing.JTextArea jTextArea16;
    private javax.swing.JTextArea jTextArea17;
    private javax.swing.JTextArea jTextArea18;
    private javax.swing.JTextArea jTextArea19;
    private javax.swing.JTextArea jTextArea2;
    private javax.swing.JTextArea jTextArea20;
    private javax.swing.JTextArea jTextArea21;
    private javax.swing.JTextArea jTextArea22;
    private javax.swing.JTextArea jTextArea23;
    private javax.swing.JTextArea jTextArea27;
    private javax.swing.JTextArea jTextArea28;
    private javax.swing.JTextArea jTextArea29;
    private javax.swing.JTextArea jTextArea3;
    private javax.swing.JTextArea jTextArea30;
    private javax.swing.JPasswordField jTextArea4;
    private javax.swing.JTextArea jTextArea5;
    private javax.swing.JTextArea jTextArea6;
    private javax.swing.JPasswordField jTextArea7;
    private javax.swing.JTextArea jTextArea8;
    private javax.swing.JTextArea jTextArea9;
    private javax.swing.JButton login;
    private javax.swing.JButton logout;
    private javax.swing.JButton register;
    private javax.swing.JButton submit;
    private javax.swing.JButton track;
    // End of variables declaration//GEN-END:variables
}
